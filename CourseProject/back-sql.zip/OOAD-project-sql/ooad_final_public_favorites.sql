INSERT INTO public.favorites (username, h_id) VALUES ('wangyu', 3);
INSERT INTO public.favorites (username, h_id) VALUES ('123456', 4);
INSERT INTO public.favorites (username, h_id) VALUES ('yzd', 2);
INSERT INTO public.favorites (username, h_id) VALUES ('123456', 5);
