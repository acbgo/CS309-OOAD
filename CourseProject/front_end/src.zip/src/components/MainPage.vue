<template>
  <div class="Main">
    <div class="Header" style="background-color: #d9ecff">
      <div style="display: flex; justify-content: center">
        <img :src="hotel" alt @click="Home" style="width: 50px;">
        <img :src="contact" alt @click="ContactUs" style="width: 50px; margin-left: 20px">
        <img :src="loginImg" alt @click="LoginMethods" style="width: 50px; margin-left: 20px">
      </div>
    </div>
    <div class="Body" style="margin-top: -21px">
      <div class="Box">
        <component :is="componentName"></component>
      </div>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import ContactUs from './subPage/ContactUs.vue'
import SubMain from './subPage/SubMain.vue'
import Reservation from './subPage/Reservation.vue'
import Login from './subPage/Login.vue'
import Register from './subPage/Register.vue'
import BigMap from './subPage/BigMap.vue'

export default {
  name: 'MainPage',
  components: {SubMain, ContactUs},
  data () {
    return {
      hotel: require('../assets/svgs/hotel.svg'),
      contact: require('../assets/svgs/contact.svg'),
      loginUser: '',
      loginImg: '',
      HaveLogin: false,
      componentName: '',
      lastPage: '',
      components: {
        ContactUs,
        SubMain,
        Reservation,
        Login,
        Register,
        BigMap
      }
    }
  },
  mounted () {
    this.LoadImg()
    this.Home()
  },
  methods: {
    Home () {
      this.componentName = SubMain
      this.lastPage = this.componentName
    },
    ContactUs () {
      this.lastPage = this.componentName
      this.componentName = ContactUs
    },
    LoadImg () {
      if (this.HaveLogin) {
        this.loginImg = require('../assets/svgs/login1.svg')
      } else {
        this.loginImg = require('../assets/svgs/login0.svg')
      }
    },
    LoginMethods () {
      if (this.HaveLogin) {
        alert(this.loginUser)
      } else {
        this.lastPage = this.componentName
        this.componentName = Login
      }
    },
    reservation () {
      this.lastPage = this.componentName
      this.componentName = Reservation
    }
  }
}
</script>

<style scoped>

</style>
