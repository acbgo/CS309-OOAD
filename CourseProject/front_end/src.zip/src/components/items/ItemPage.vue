<template>
  <div class="item">
    <slot>

    </slot>
  </div>
</template>

<script>
export default {
  name: 'itemPage'
}
</script>

<style scoped>
.item{
  height: 200px;
  width: 900px;
}
</style>
