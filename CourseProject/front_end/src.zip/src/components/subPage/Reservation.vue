<template>
  <div class="Main">
    <div class="Select">
      <div class="Box" style="display: flex; justify-content: center;">
        <div class="Destination">
          <label>目的地</label>
          <div>
            <el-cascader v-model="hotelForm.destination"
                         placeholder="destination"
                         :options="destinations"
                         filterable
            >
            </el-cascader>
          </div>
        </div>
        <div class="DateRange" style="margin-left: 20px; display: block">
          <span style="display: block">入住时间</span>
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期">
          </el-date-picker>
        </div>
        <div class="Number" style="margin-left: 20px">
          <span style="display: block">入住人数</span>
          <div>
            <el-select v-model="hotelForm.number" placeholder="Number of occupancy">
              <el-option v-for="item in numbers"
                         :key="item.label"
                         :value="item.label"/>
            </el-select>
          </div>
        </div>
        <div class="KeyWord" style="margin-left: 20px">
          <span style="display: block">关键词</span>
          <div>
            <input v-model="keyWord"
                   style="height: 36px; width: 180px; border: #666666; border-radius: 4px; margin-top: 1px"
                   placeholder="    酒店名/地标">
          </div>
        </div>
      </div>
      <div class="Check" style="margin-top: 20px">
        <div class="Grand" style="display: flex">
          <span style="margin-left: 450px">星级</span>
          <el-checkbox-group v-model="grand" style="margin-left: 20px" :max="1">
            <el-checkbox v-for="grand in grands" :label="grand.label" :key="grand.value">{{ grand.label }}</el-checkbox>
          </el-checkbox-group>
        </div>
        <hr width="680px" color="black" size="1px">
        <div class="price">
          <span style="margin-left: -5px">价格</span>
          <el-radio-group v-model="price" style="margin-left: 16px">
            <el-radio v-for="price in prices" :label="price.label" :key="price.value">{{ price.label }}</el-radio>
          </el-radio-group>
        </div>
      </div>
      <div class="Button" style="margin-left: 919px; margin-top: -50px">
        <el-button style="width: 120px; border-radius: 10px; background-color: #4c8df4; color: snow;">搜索</el-button>
      </div>
    </div>
    <div class="Show" style="display: flex">
      <div class="Left" style="margin-left: 249px">
        <el-row v-for="hotel in hotels" :key="hotel.id" style="margin-top: 10px">
          <ItemPage style="background-color: #F0FFFF; display: flex">
            <div class="HotelImg">
              <img src="../../assets/imgs/img.png" style="height: 200px">
            </div>
            <div class="Detail" style="display: block;width: 370px; margin-left: 30px" @click="setMap(hotel)">
              <div class="name" style="margin-top: 20px; height: 40px">
                <span style="float: left; font-size: 30px; font-weight: bold;">{{ hotel.name }}</span>
              </div>
              <div class="position" style="height: 40px; margin-top: 20px">
                <span style="float: left; display: block">地址:{{ hotel.position }}</span>
                <br>
                <br>
                <span style="float: left; display: block">这里展示详细信息</span>
              </div>
              <div class="tag" style="height: 30px">
                <br>
                <el-tag style="float: left; margin-top: 20px">{{ hotel.type }}</el-tag>
              </div>
            </div>
            <div class="ItemRight">
              <el-rate v-model="hotel.rate" disabled show-score text-color="#ff9900"
                       style="margin-top: 20px; margin-left: 40px"></el-rate>
              <el-button
                style="display: block; margin-left: 100px; margin-top: 100px; color: #4c8df4; border: 1px solid #4c8df4; border-radius: 5px;">
                查看详情
              </el-button>
            </div>
          </ItemPage>
        </el-row>
      </div>
      <div class="Right">
        <div class="Map" id="gdMap" style="margin-left: 20px; margin-top: 20px"></div>
        <el-button style="margin-top: 20px; background-color: #4c8df4; color: snow; border-radius: 10px;" @click="showBigMap">查看全国分店</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import ItemPage from '../items/ItemPage.vue'
import BigMap from './BigMap.vue'
import AMapLoader from '@amap/amap-jsapi-loader'

export default {
  name: 'Reservation',
  created () {
    this.initMap()
  },
  components: {
    ItemPage
  },
  data () {
    return {
      destination: '',
      dateRange: '',
      number: 0,
      keyWord: '',
      grand: [],
      grands: [
        {label: '不限', value: 0},
        {label: '经济型', value: 1},
        {label: '舒适型', value: 2},
        {label: '高档型', value: 3},
        {label: '豪华型', value: 4},
        {label: '别墅型', value: 5}
      ],
      price: [],
      prices: [
        {label: '不限', value: 0},
        {label: '200以下', value: 1},
        {label: '200-400', value: 2},
        {label: '400-600', value: 3},
        {label: '600-800', value: 4},
        {label: '800以上', value: 5}
      ],
      hotelForm: {
        grade: '',
        destination: '',
        number: ''
      },
      destinations: [
        {
          label: '广东',
          value: 'guangdong',
          children: [
            {
              label: '深圳',
              value: 'ShenZen',
              children: [
                {label: '南山', value: 'NanShan'},
                {label: '宝安', value: 'BaoAn'},
                {label: '龙岗', value: 'LongGang'},
                {label: '龙华', value: 'LongHua'}
              ]
            },
            {
              label: '广州',
              value: 'GuangZhou',
              children: [
                {label: '天河', value: 'TianHe'},
                {label: '白云', value: 'BaiYun'},
                {label: '海珠', value: 'HaiZhu'},
                {label: '越秀', value: 'YueXiu'}
              ]
            }
          ]
        }
      ],
      numbers: [
        {label: 1, value: 1},
        {label: 2, value: 2},
        {label: 3, value: 3},
        {label: 4, value: 4},
        {label: 5, value: 5}
      ],
      hotels: [
        {
          id: 1,
          name: 'hotel1',
          position: '南科大',
          type: '经济型',
          rate: 4.9,
          lngLat: [113.998556, 22.60024]
        },
        {
          id: 2,
          name: 'hotel2',
          position: '深大',
          type: '舒适型',
          rate: 4.5,
          lngLat: [113.992239, 22.598417]
        },
        {
          id: 3,
          name: 'hotel3',
          position: '哈工深',
          type: '豪华型',
          rate: 4.3,
          lngLat: [113.970869, 22.58679]
        }
      ],
      map: null
    }
  },
  methods: {
    initMap () {
      AMapLoader.load({
        key: '812f0a2e5932119449b4cb59f3474742', // 申请好的Web端开发者Key，首次调用 load 时必填
        version: '2.0', // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
        plugins: [] // 需要使用的的插件列表，如比例尺'AMap.Scale'等
      }).then((AMap) => {
        this.map = new AMap.Map('gdMap', {
          center: [113.998556, 22.60024],
          zoom: 15,
          draggable: true
        })
        let marker = new AMap.Marker({
          position: new AMap.LngLat(113.998556, 22.60024), // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
          title: '南科大'
        })
        this.map.add(marker)
      }).catch(e => {
        console.log(e)
      })
    },
    setMap (hotel) {
      AMapLoader.load({
        key: '812f0a2e5932119449b4cb59f3474742', // 申请好的Web端开发者Key，首次调用 load 时必填
        version: '2.0', // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
        plugins: [] // 需要使用的的插件列表，如比例尺'AMap.Scale'等
      }).then((AMap) => {
        this.map = new AMap.Map('gdMap', {
          center: hotel.lngLat,
          zoom: 15,
          draggable: true
        })
        let marker = new AMap.Marker({
          position: new AMap.LngLat(hotel.lngLat[0], hotel.lngLat[1]), // 经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
          title: '南科大'
        })
        this.map.add(marker)
      }).catch(e => {
        console.log(e)
      })
    },
    showBigMap () {
      this.$parent.componentName = BigMap
    }
  }
}
</script>

<style scoped>
.Select {
  background: rgba(131, 139, 139, 0.3);
  margin-top: 21px;
  padding-top: 30px;
  height: 158px;
}

.Map {
  height: 400px;
  width: 340px;
  border: 1px solid cornflowerblue;
  background-color: #4c8df4;
}
</style>
