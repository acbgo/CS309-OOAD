<template>
  <div class="Main">
    <div class="Head" style="margin-top: 30px">
      <span style="font-size: 25px; font-weight: bold">点击以查询当前城市所有酒店分店</span>
    </div>
    <div class="BigMap" id="gdMap"></div>
  </div>
</template>

<script>
import VueAMap from 'vue-amap'
export default {
  name: 'BigMap',
  data () {
    return {
      map: null
    }
  },
  created () {
  },
  methods: {
    initMap () {
      VueAMap.initAMapApiLoader({
        key: '812f0a2e5932119449b4cb59f3474742',
        plugin: ['AMap.Autocomplete', 'AMap.PlaceSearch', 'AMap.Scale', 'AMap.OverView', 'AMap.ToolBar', 'AMap.MapType', 'AMap.Geolocation', 'AMap.Geocoder', 'AMap.AMapManager', 'AMap.Marker'],
        v: '2.0'
      })
      this.map = new VueAMap.Map('gdMap', {
        center: [117.000923, 36.675807],
        zoom: 11
      })
    }
  }
}
</script>

<style scoped>
.BigMap {
  margin-top: 20px;
  margin-left: 250px;
  height: 600px;
  width: 1100px;
  border: 1px solid cornflowerblue;
  background-color: #4c8df4;
}
</style>
