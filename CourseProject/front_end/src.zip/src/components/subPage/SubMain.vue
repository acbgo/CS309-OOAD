<template>
  <div class="Main">
    <div class="Select" style="display: flex; justify-content: center;">
      <div class="Grade">
        <h3>星级</h3>
        <div>
          <el-select v-model="hotelForm.grade" placeholder="Grade">
            <el-option v-for="item in hotelGradeOptions"
                       :key="item.label"
                       :value="item.label"/>
          </el-select>
        </div>
      </div>
      <div class="Destination" style="margin-left: 20px">
        <h3>目的地</h3>
        <div>
          <el-cascader v-model="hotelForm.destination"
                       placeholder="destination"
                       :options="destinations"
                       filterable
          >
          </el-cascader>
        </div>
      </div>
      <div class="DateRange" style="margin-left: 20px; display: block">
        <h3>入住时间</h3>
        <el-date-picker
          v-model="dateRange"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期">
        </el-date-picker>
      </div>
      <div class="Search" style="margin-left: 20px; margin-top: 57px;">
        <el-button class="search_btn" @click="search"
                   style="background-color: #d9ecff; color: #222222; border-radius: 20px; width: 120px; font-size: 18px">
          搜索
        </el-button>
      </div>
    </div>
    <div class="Bottom" :style="{height: Height}">
      <div style="padding-top: 270px">
        <span style="font-size: 40px">南科大酒店，给您家的感觉</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SubMain',
  created () {
    let screenHeight = `${document.documentElement.clientHeight - 238}px`
    this.$nextTick(() => {
      this.Height = screenHeight
    })
  },
  data () {
    return {
      Height: '',
      nextPage: '',
      dateRange: '',
      hotelForm: {
        grade: '',
        destination: '',
        number: ''
      },
      hotelGradeOptions: [
        {label: '经济型', value: 1},
        {label: '舒适型', value: 2},
        {label: '高档型', value: 3},
        {label: '豪华型', value: 4},
        {label: '别墅型', value: 5}
      ],
      destinations: [
        {
          label: '广东',
          value: 'guangdong',
          children: [
            {
              label: '深圳',
              value: 'ShenZen',
              children: [
                {label: '南山', value: 'NanShan'},
                {label: '宝安', value: 'BaoAn'},
                {label: '龙岗', value: 'LongGang'},
                {label: '龙华', value: 'LongHua'}
              ]
            },
            {
              label: '广州',
              value: 'GuangZhou',
              children: [
                {label: '天河', value: 'TianHe'},
                {label: '白云', value: 'BaiYun'},
                {label: '海珠', value: 'HaiZhu'},
                {label: '越秀', value: 'YueXiu'}
              ]
            }
          ]
        }
      ]
    }
  },
  methods: {
    search () {
      this.$parent.reservation()
      // console.log('click search')
      // console.log(this.hotelForm)
      // let grade = this.hotelForm.grade * 1
      // var url = 'http://10.24.3.53:8181/findHotels?grade=' + grade + '&city=' + this.hotelForm.destination[0] + '&district=' + this.hotelForm.destination[1]
      // console.log(url)
      // var xmlhttp = new XMLHttpRequest()
      // xmlhttp.open('POST', url, false)
      // xmlhttp.send()
      // var myData = xmlhttp.responseText
      // console.log(myData)
      // if (myData === true) {
      //   this.$router.push('/home')
      // } else {
      //   alert('用户不存在')
      // }
    }
  }
}
</script>

<style scoped>
.Select {
  /*background:rgba(255,255,255,0.3);*/
  background: rgba(131, 139, 139, 0.3);
  margin-top: 21px;
  padding-top: 30px;
  height: 180px;
}

.Bottom {
  background: url('../../assets/imgs/bg.jpg') center;
  /*width: 1536px;*/
  /*height: 532px;*/
  margin-top: -22px;
}
</style>
