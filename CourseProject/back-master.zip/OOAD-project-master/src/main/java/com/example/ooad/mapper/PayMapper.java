package com.example.ooad.mapper;

public interface PayMapper {
}
